package com.example.demo.coder;

import jakarta.persistence.*;
import org.hibernate.annotations.GenericGenerator;

@Entity
@Table
public class Coder
{
    @Id
    @SequenceGenerator(name = "coder_sequence", sequenceName = "coder_sequence", allocationSize = 1)
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "coder_sequence")
    private Long id;
    private String username;
    private String email;
    private String password;

    public Coder()
    {

    }

    public Coder(String username, String email, String password)
    {
        this.username = username;
        this.email = email;
        this.password = password;
    }

    public Coder(String username, String email, String password, Long id)
    {
        this.username = username;
        this.email = email;
        this.password = password;
        this.id = id;
    }

    public String getUsername()
    {
        return username;
    }

    public String getEmail()
    {
        return email;
    }

    public String getPassword()
    {
        return password;
    }

    public Long getId()
    {
        return id;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    @Override
    public String toString() {
        return "User{" +
                "username='" + username + '\'' +
                ", email='" + email + '\'' +
                ", password='" + password + '\'' +
                ", id=" + id +
                '}';
    }
}
