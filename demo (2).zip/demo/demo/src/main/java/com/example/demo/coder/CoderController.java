package com.example.demo.coder;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping(path = "api/v1/coder")
public class CoderController
{
    private final CoderService coderService;

    @Autowired
    public CoderController(CoderService CoderService) {
        this.coderService = CoderService;
    }

    @GetMapping
    public List<Coder> getCoder()
    {
        return coderService.getCoder();
    }

    @PostMapping
    public void registerNewCoder(@RequestBody Coder coder)
    {
        coderService.addnewCoder(coder);
    }

    @DeleteMapping(path = "{coderId}")
    public void deleteCoder(@PathVariable("coderId") Long coderId)
    {
        coderService.deleteCoder(coderId);
    }

    public void updateCoder(
            @PathVariable("coderId") Long coderId,
            @RequestParam(required = false) String username,
            @RequestParam(required = false) String email,
            @RequestParam(required = false) String password
    )
    {
        coderService.updateCoder(coderId, username, email, password);
    }

}
