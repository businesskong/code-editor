package com.example.demo.coder;

import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Objects;
import java.util.Optional;

@Service
public class CoderService
{

    private final CoderRepository coderRepository;

    @Autowired
    public CoderService(CoderRepository coderRepository) {
        this.coderRepository = coderRepository;
    }

    public List<Coder> getCoder()
    {
        return coderRepository.findAll();
    }

    public void addnewCoder(Coder coder)
    {
        Optional<Coder> coderOptional = coderRepository.findCoderbyEmail(coder.getEmail());
        if(coderOptional.isPresent())
        {
            throw new IllegalStateException("email taken");
        }

        coderRepository.save(coder);
    }

    public void deleteCoder(Long coderId)
    {

        boolean exists = coderRepository.existsById(coderId);
        if(!exists)
        {
            throw new IllegalStateException("coder with id " + coderId + " does not exist");
        }
        coderRepository.deleteById(coderId);

    }

    @Transactional
    public void updateCoder(Long coderId, String username, String email, String password)
    {
        Coder coder = coderRepository.findById(coderId).orElseThrow(() -> new IllegalStateException("coder with id " + coderId + " does not exist"));

        if(username != null && !username.isEmpty() && !Objects.equals(coder.getUsername(), username))
        {
            Optional<Coder> coderOptional = coderRepository.findCoderbyUsername(username);
            if(coderOptional.isPresent())
            {
                throw new IllegalStateException("username taken");
            }
            coder.setUsername(username);
        }
        if(email != null && !email.isEmpty() && !Objects.equals(coder.getEmail(), email))
        {
            Optional<Coder> coderOptional = coderRepository.findCoderbyEmail(email);
            if(coderOptional.isPresent()) {
                throw new IllegalStateException("email taken");
            }
            coder.setEmail(email);
        }


    }
}
