package com.example.demo.coder;

import org.springframework.context.annotation.Configuration;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;

import java.util.List;

@Configuration
public class CoderConfig
{

    @Bean
    CommandLineRunner commandLineRunner(CoderRepository repository)
    {
        return args -> {
            Coder leader = new Coder("Businesskong", "lawrencedouglas02@gmail.com", "bonk");
            repository.saveAll(List.of(leader));

        };
    }
}
