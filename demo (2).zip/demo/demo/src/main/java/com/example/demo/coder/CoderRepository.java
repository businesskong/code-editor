package com.example.demo.coder;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface CoderRepository extends JpaRepository<Coder, Long>
{
    @Query("SELECT c FROM Coder c WHERE c.email = ?1")
    Optional<Coder> findCoderbyEmail(String email);

    @Query("SELECT c FROM Coder c WHERE c.username = ?1")
    Optional<Coder> findCoderbyUsername(String email);
}
